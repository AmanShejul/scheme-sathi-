---
name: Scheme Sathi Civic Authority System
colors:
  surface: '#fcf9f5'
  surface-dim: '#dcdad6'
  surface-bright: '#fcf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ef'
  surface-container: '#f0edea'
  surface-container-high: '#eae8e4'
  surface-container-highest: '#e5e2de'
  on-surface: '#1c1c1a'
  on-surface-variant: '#444748'
  inverse-surface: '#31302e'
  inverse-on-surface: '#f3f0ed'
  outline: '#747878'
  outline-variant: '#c4c7c8'
  surface-tint: '#5d5f5f'
  primary: '#5d5f5f'
  on-primary: '#ffffff'
  primary-container: '#ffffff'
  on-primary-container: '#747676'
  inverse-primary: '#c6c6c7'
  secondary: '#5d5f5e'
  on-secondary: '#ffffff'
  secondary-container: '#dfe0df'
  on-secondary-container: '#616362'
  tertiary: '#a04100'
  on-tertiary: '#ffffff'
  tertiary-container: '#ffffff'
  on-tertiary-container: '#c65200'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c7'
  on-primary-fixed: '#1a1c1c'
  on-primary-fixed-variant: '#454747'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c7c6'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb693'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7a3000'
  background: '#fcf9f5'
  on-background: '#1c1c1a'
  surface-variant: '#e5e2de'
typography:
  display-lg:
    fontFamily: Times New Roman, Times, serif
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.01em
  display-lg-mobile:
    fontFamily: Times New Roman, Times, serif
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg:
    fontFamily: Times New Roman, Times, serif
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Times New Roman, Times, serif
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Times New Roman, Times, serif
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Times New Roman, Times, serif
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  title-lg:
    fontFamily: Times New Roman, Times, serif
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  title-md:
    fontFamily: Times New Roman, Times, serif
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
  body-lg:
    fontFamily: Times New Roman, Times, serif
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Times New Roman, Times, serif
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Times New Roman, Times, serif
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Times New Roman, Times, serif
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Times New Roman, Times, serif
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Times New Roman, Times, serif
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes an authoritative, dignified, and exceptionally clear public-service interface for Indian citizens navigating welfare, subsidies, and citizen-entitlement programs. It combines the sober clarity of official gazettes and statutory instruments with contemporary civic web architecture.

### Personality & Tone
- **Dignified & Institutional:** Evokes constitutional duty, state accountability, and structured public governance.
- **Approachable & Trustworthy:** Direct, unhurried, and calm. Free of predatory commercial hooks, unnecessary flourishes, or algorithmic novelty.
- **Equitable & Clear:** Designed for deep accessibility across varying literacies, devices, and bandwidth constraints. High legibility and unyielding structural predictability take precedence.

### Design Movement
**Civic Modernism & Archival Precision.** The visual language rejects decorative trends—such as glowing gradients, saturated status badges, or frosted glass—in favor of crisp mechanical borders, warm ivory surfaces, deliberate editorial margins, and restrained institutional orange accents. The interface mirrors carefully printed administrative paperwork, organized with modern information architecture.

## Colors

The color palette is strictly restrained to mineral warm whites, off-white card canvas tones, warm gray framing borders, dark charcoal ink typography, and deep saffron/orange administrative accents. No blue, cyan, teal, green, purple, yellow, or crimson red is permitted across any layout or functional state.

### Structural Foundations
- **Canvas Base:** `#FBFBFA` serves as the primary window canvas, delivering soft, warm daylight contrast.
- **Card & Tier 1 Surfaces:** Pure White (`#FFFFFF`) isolates operational zones, tables, and scheme cards.
- **Inset / Secondary Tonal Canvas:** `#F5F5F3` demarcates grouped fieldsets, sticky table heads, and step indicators.

### Line Work & Framing
- **Standard Border:** `#E4E2DC` creates sharp, architectural delineations between sections and structural panels.
- **Deepened Border / Focus Rule:** `#D4D2CB` structures divider rules, active containers, and non-focused input borders.
- **Accent Border:** `#FFCC99` wraps active recommendations, citizen priority bundles, and selected cards.

### Typographic Inks
- **Primary Ink (Headlines & Labels):** `#222220` delivers near-black clarity without clinical harshness.
- **Body Ink:** `#3E3D39` provides optimal readability for long-form statutory eligibility criteria and scheme directives.
- **Secondary Ink:** `#6E6D68` provides subdued clarity for timestamps, metadata, reference codes, and table headers.
- **Muted Ink:** `#8E8D88` denotes disabled elements, structural breadcrumb dividers, and decorative rules.

### Institutional Accent & Status Tones
Status differentiation is achieved exclusively through the saffron/orange and charcoal/stone spectrum:
- **Primary Accent / Interactive:** `#D95B00` (deep saffron) acts as the single locus of focus for forward progression, verified scheme stamps, and primary triggers.
- **Hover / Compressed Interaction:** `#E65100` provides intentional tactile feedback.
- **Surface Highlight / Verified Tint:** `#FFF3E8` serves as the tinted surface layer for qualifying bundles, active tags, alerts, and operational focus backings.
- **Status Alternatives:** 
  - *Active / Eligible / Verified:* `#D95B00` text on `#FFF3E8` with `#FFCC99` border.
  - *Neutral / Pending / Documentation Required:* `#3E3D39` text on `#F5F5F3` with `#D4D2CB` border.
  - *Inactive / Not Eligible:* `#8E8D88` text on `#FBFBFA` with `#E4E2DC` border.

## Typography

The design system exclusively uses `Times New Roman` across all viewports, levels, forms, and administrative records. This deliberate uniform typographic treatment anchors the portal directly in the lineage of official governmental decrees, national gazettes, and formal civic communication.

### Hierarchy & Rules
- **Display & Headlines:** Heavy weights (`700`) must be used for system titles, scheme categories, and national bundle identifiers. Heading sizes maintain classical line height ratios to eliminate vertical cramming.
- **Official Documentation Body:** Standard text is set in `regular` (`400`) weight at `16px` (`body-md`) and `18px` (`body-lg`) to ensure legal eligibility prerequisites, procedural caveats, and benefit matrices remain effortless to scan for senior citizens and low-resolution screen readers.
- **Labels & Identification Strings:** Metadata keys, application registration numbers, and section trackers use capitalized or emphasized `Times New Roman` bold treatments with conservative letter-spacing (`0.02em` to `0.04em`) to mirror official rubber stamps and gazette section markers.

## Layout & Spacing

The portal adheres to a 12-column structured grid system designed for symmetrical, authoritative, and legible civic documentation layouts.

### Structural Grid & Rhythm
- **Desktop (1200px and wider):** 12-column layout with `1.5rem` (`24px`) gutters and a centered maximum width of `1240px`. Exterior canvas padding is fixed at `2rem` (`32px`).
- **Tablet (768px – 1199px):** 8-column layout with `1rem` (`16px`) gutters and `1.5rem` (`24px`) screen margins.
- **Mobile (Up to 767px):** 4-column single-flow vertical stacking with `0.75rem` (`12px`) gutters and `1rem` (`16px`) margins.

### Spacing Scale & Usage
- `space-xs` (4px): Used between closely related text/label pairs and inside micro-badges.
- `space-sm` (8px): Used between form labels and inputs, inline badge arrays, and action icon offsets.
- `space-md` (16px): Internal padding for standard table cells, form item stacks, and compact metadata modules.
- `space-lg` (24px): Standard inner card padding, card row separations, and inter-component margins.
- `space-xl` (40px): Section breaks, thematic document divisions, and primary workflow cluster offsets.

## Elevation & Depth

Visual hierarchy is communicated through planar surface shifts, mechanical borders, and ultra-subtle, uncolored shadow treatments. In adherence to formal governmental rigor, all glassmorphism, colored light emissions, blurred backdrops, and floating atmospheric shadows are strictly forbidden.

### Depth Hierarchy
1. **Canvas Tier (Ground Zero):** `#FBFBFA` base canvas. Zero elevation.
2. **Structural Tier (Cards, Containers):** Pure `#FFFFFF` resting cleanly above the ground layer, bordered by a single crisp `1px solid #E4E2DC` stroke. Shadow is restrained to `0 1px 3px rgba(34, 34, 32, 0.04)`.
3. **Selected / Highlighting Tier (Optimized Schemes, Recommendations):** Grounded `#FFFFFF` surface bordered by `1px solid #FFCC99` with an optional top structural accent rule in `#D95B00` (3px thickness).
4. **Interactive & Focus Tier (Modals, Overlays, Dropdowns):** `#FFFFFF` surface outlined with `1px solid #D4D2CB` and elevated with a restrained, directional shadow: `0 4px 12px rgba(34, 34, 32, 0.08)`.

## Shapes

The interface embraces a disciplined, near-rectilinear shape language with micro-radii ranging between `2px` and `4px`. This reinforces the visual weight of printed government certifications and official registers while softening hard digital corners just enough for ergonomic clarity.

### Corner Radius Standards
- **Cards, Enclosures & Data Tables:** Fixed `2px` or `4px` corner radius.
- **Form Controls & Inputs:** Fixed `2px` radius for a crisp, paper-form ledger feel.
- **Buttons, Action Bars & Status Badges:** Fixed `2px` radius. Pill shapes (`rounded-full`) are prohibited.
- **Dividers & Structural Rules:** Hard `0px` cutoffs with standard horizontal or vertical strokes.

## Components

### Buttons
- **Primary Civic Action:** Solid saffron orange (`#D95B00`) background, `#FFFFFF` text, `2px` border radius, font `Times New Roman` bold `14px`. Hover state shifts to `#E65100`. Active state drops shadow and darkens to `#BF4F00`. Padding: `10px 20px`.
- **Secondary / Administrative Action:** White (`#FFFFFF`) surface, `1px solid #D4D2CB` border, text in `#222220`. Hover shifts background to `#F5F5F3`.
- **Tertiary / Link Action:** Transparent background, text in `#D95B00` with underline on hover. No container border.

### Status Indicators & Badges
- Strictly bounded to orange and warm gray scales.
- **Verified / High Match:** `#FFF3E8` background, `#FFCC99` border, `#D95B00` bold text.
- **Under Review / Standard:** `#F5F5F3` background, `#D4D2CB` border, `#3E3D39` bold text.
- **Document Missing / Inactive:** `#FBFBFA` background, `#E4E2DC` border, `#6E6D68` text.

### Cards & Scheme Containers
- Base card: White (`#FFFFFF`) with a `1px solid #E4E2DC` boundary, `4px` corner radius, `24px` internal padding.
- **Optimized Scheme Recommendation Card:** Distinct structural treatment consisting of a `3px` solid top border in `#D95B00`, a subtle `#FFF3E8` header badge displaying calculated savings/subsidy metrics, and explicit eligibility checklist items styled with crisp warm gray borders.

### Input Fields & Controls
- **Text Inputs & Dropdowns:** Pure `#FFFFFF` background, `1px solid #D4D2CB` border, `4px` padding inside an overall input height of `44px`. Placeholder text set in `#8E8D88`. On active focus: border changes to `1.5px solid #D95B00`, with a `2px` subtle halo using `#FFF3E8`.
- **Checkboxes & Radios:** Sharp square and circular tokens with `1.5px solid #D4D2CB` outer boundaries. Selected state fills with `#D95B00` housing a crisp white mark.

### Data Tables & Gazette Registers
- Sticky header set in `#F5F5F3` with a bottom border of `1.5px solid #D4D2CB`. Column headers formatted in bold `Times New Roman` (`12px`, uppercase, `#6E6D68`). Rows alternate with pure `#FFFFFF` and `#FBFBFA`, separated by hairline rules (`1px solid #E4E2DC`).